<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>HI OMAR</h1>
<div>
    <a href="<?php echo e(url('/')); ?>">Home</a>
    <a href="<?php echo e(url('/about-ucas')); ?>">About</a>
    <a href="#">students</a>
</div>
<br>
<table border=1>
    <tr>
        <td>#</td>
        <td>username</td>
        <td>Productname</td>
        <td>Subtotal</td>
        <td>tax</td>
        <td>total</td>
        <td>discount</td>
        <td>quantity</td>
    </tr>
    <?php $__currentLoopData = $Order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($orders->id); ?></td>
        <td><?php echo e($orders->user_id); ?></td>
        <td><?php echo e($orders->product_id); ?></td>
        <td><?php echo e($orders->subtotal); ?></td>
        <td><?php echo e($orders->tax); ?></td>
        <td><?php echo e($orders->total); ?></td>
        <td><?php echo e($orders->discount); ?></td>
        <td><?php echo e($orders->quantity); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\example-app\resources\views/home/index.blade.php ENDPATH**/ ?>